
public class ItemOutOfStockException extends Exception {
	
}
